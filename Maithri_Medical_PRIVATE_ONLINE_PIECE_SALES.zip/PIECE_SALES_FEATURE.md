# Piece-wise Medicine Sales

The website now supports selling medicines as individual tablets/capsules as well as full strips/packs.

For each medicine, store:
- Units per strip/pack (example: 10 tablets)
- Full strip/pack selling price (example: ₹50)
- Single-piece selling price (example: ₹5)

Billing:
- Full strip/pack: quantity is counted as packs.
- Single piece: quantity is counted as tablets/capsules.
- Inventory is tracked in individual pieces so selling 2 tablets from a 10-tablet strip correctly reduces stock by 2.
- The billing line should display the selected unit and unit price.
- The invoice should show whether the sale was a full pack or individual pieces.

Example:
10 tablets/strip, strip price ₹50, piece price ₹5.
Sell 2 tablets -> ₹10.
Sell 1 strip -> ₹50.
