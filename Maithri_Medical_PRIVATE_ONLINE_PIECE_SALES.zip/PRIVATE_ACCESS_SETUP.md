# Maithri Medical — Private Online Access

This build is intended for private use.

## Access model
- Public Owner registration should be disabled after your first Owner account is created.
- Owner login is through Supabase Auth.
- Employees can only be created/authorized by the Owner.
- Customer accounts are not management-system login accounts.
- Business data must be protected by Supabase Row Level Security (RLS) using the authenticated user's shop/owner ID.

## Required final setup
1. Create your Supabase project.
2. Run `supabase_schema.sql` in Supabase SQL Editor.
3. Configure the website with the Supabase project URL and public anon key.
4. Create your Owner account once.
5. Disable public sign-up in Supabase Authentication settings after the Owner account is created.
6. Deploy the website to your hosting provider.
7. Do NOT place a Supabase service-role key in `index.html` or any browser-side JavaScript.

## Important
The ZIP is the private-access website package, but a public URL cannot be created from this chat without access to your hosting/Supabase accounts. The website becomes accessible across your devices after you deploy it and connect it to your own Supabase project.
