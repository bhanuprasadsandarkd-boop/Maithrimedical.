MAITHRI MEDICAL & GENERAL STORES — FULL FRONT-END VERSION
=============================================================
Demo:
Owner: owner / 1234
Employee: staff / 1234

Included:
- Owner and employee login
- Role-based navigation
- Dashboard
- Medicine batch inventory
- MRP, purchase price, margin, selling price
- Quantity, rack, company, batch, expiry and GST fields
- Low-stock and expiry alerts
- Billing with customer/payment/discount
- Automatic stock deduction
- Printable invoice
- Customer details and credit/outstanding
- Suppliers
- Purchase records
- Expenses
- Employees
- Sales/profit/expense reports
- JSON backup/export/import
- Shop settings

IMPORTANT:
This is a browser/local-storage application, not a production-hosted pharmacy system.
It does not provide secure server-side authentication, multi-device synchronization,
barcode hardware integration, GST/legal compliance validation, or prescription/controlled
medicine workflows. Do not use demo passwords in production.

For production deployment, add a secure backend database, hashed passwords, HTTPS,
server-side authorization, audit logs, backups, barcode support, GST invoice rules,
prescription/regulated-medicine controls, and data retention/privacy controls.


FIXED: Customer purchase history is now linked to billing sales, customer search suggestions are available, and each customer has a View Purchase History option. Existing customer totals/history are rebuilt from saved sales data.

FIXED: Billing now has separate Customer Name and Mobile Number fields. Both are saved with each sale, and selecting a saved customer name/mobile auto-fills the other field.

PIECE SALES: Medicines can be configured with units-per-pack, pack price and single-piece price. Billing can sell full packs or individual pieces, with inventory tracked accurately.
