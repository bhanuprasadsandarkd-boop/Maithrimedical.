# Maithri Medical — Online Database Setup

This version uses **Supabase Auth + PostgreSQL** so accounts and business data work across phones/computers.

## 1. Create Supabase project
Create a project at https://supabase.com/.

## 2. Run the database schema
Open **SQL Editor**, paste `supabase_schema.sql`, and run it.

## 3. Configure Auth
In **Authentication → Providers → Email**, enable Email/Password.
For this username/password version, email confirmation should be disabled because the site creates an internal login email from the username.

## 4. Deploy the employee function
The folder `supabase/functions/create-employee/index.ts` is the secure server-side employee-registration endpoint. Deploy it with the Supabase CLI and set the project's service-role secret as `SUPABASE_SERVICE_ROLE_KEY`.

## 5. Put project credentials in index.html
Near the start of the main script, set:

```js
const SUPABASE_URL = "YOUR_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_ANON_KEY";
```

The anon key is safe for browser use when Row Level Security is enabled. **Never put the service-role key in index.html.**

## 6. First owner account
Use **Owner Registration** in the website. The account is created in Supabase Auth and a shop/profile is created automatically.

## 7. Employee accounts
Log in as Owner → Employees → Add Employee. Employee creation goes through the secure Edge Function, so the password is handled by Supabase Auth rather than stored in the website database.

## 8. Shared business data
Stock, customers, sales, purchases, suppliers, expenses, employees and settings are stored in the shop's online `shops.data` record. Every member of the same shop sees the same data after login.

## Important
The old browser-only data in localStorage is not automatically uploaded. Export the old website data first if you need to migrate existing records. Do not delete the old site until the migration is verified.
