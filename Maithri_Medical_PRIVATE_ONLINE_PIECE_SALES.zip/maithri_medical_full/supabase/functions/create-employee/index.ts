import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const admin = createClient(supabaseUrl, serviceKey)
  const authHeader = req.headers.get('Authorization') || ''
  const token = authHeader.replace('Bearer ', '')
  const { data: { user }, error: userErr } = await admin.auth.getUser(token)
  if (userErr || !user) return new Response(JSON.stringify({error:'Unauthorized'}), {status:401,headers:{...corsHeaders,'Content-Type':'application/json'}})

  const { data: owner } = await admin.from('profiles').select('shop_id,role').eq('id',user.id).single()
  if (!owner || owner.role !== 'owner') return new Response(JSON.stringify({error:'Owner access required'}), {status:403,headers:{...corsHeaders,'Content-Type':'application/json'}})

  const body = await req.json()
  const { name, username, password, role='Cashier' } = body
  if (!name || !username || !password || password.length < 4) return new Response(JSON.stringify({error:'Name, username and password (4+ chars) are required'}), {status:400,headers:{...corsHeaders,'Content-Type':'application/json'}})

  const email = `${String(username).trim().toLowerCase()}@login.maithrimedical.local`
  const { data: created, error: createErr } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { role:'employee', full_name:name, username:String(username).trim().toLowerCase() }
  })
  if (createErr) return new Response(JSON.stringify({error:createErr.message}), {status:400,headers:{...corsHeaders,'Content-Type':'application/json'}})

  const { error: profileErr } = await admin.from('profiles').insert({id:created.user.id,shop_id:owner.shop_id,username:String(username).trim().toLowerCase(),full_name:name,role:'employee'})
  if (profileErr) {
    await admin.auth.admin.deleteUser(created.user.id)
    return new Response(JSON.stringify({error:profileErr.message}), {status:400,headers:{...corsHeaders,'Content-Type':'application/json'}})
  }
  return new Response(JSON.stringify({ok:true}), {status:200,headers:{...corsHeaders,'Content-Type':'application/json'}})
})
