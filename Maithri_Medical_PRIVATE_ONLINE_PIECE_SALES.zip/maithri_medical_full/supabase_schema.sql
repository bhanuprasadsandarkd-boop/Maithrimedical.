-- Maithri Medical: Supabase schema
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid unique not null references auth.users(id) on delete cascade,
  name text not null default 'Maithri Medical & General Stores',
  data jsonb not null default '{"settings":{"shop":"Maithri Medical & General Stores","margin":20,"low":5},"stock":[],"sales":[],"purchases":[],"customers":[],"suppliers":[],"expenses":[],"employees":[]}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  shop_id uuid not null references public.shops(id) on delete cascade,
  username text not null unique,
  full_name text not null,
  role text not null check (role in ('owner','employee')),
  created_at timestamptz not null default now()
);

create index if not exists profiles_shop_id_idx on public.profiles(shop_id);

create or replace function public.my_shop_id()
returns uuid language sql stable security definer set search_path=public
as $$ select shop_id from public.profiles where id=auth.uid() $$;

create or replace function public.login_email(p_username text)
returns text language sql stable security definer set search_path=public
as $$ select u.email from auth.users u join public.profiles p on p.id=u.id where lower(p.username)=lower(trim(p_username)) limit 1 $$;

revoke all on function public.login_email(text) from public;
grant execute on function public.login_email(text) to anon, authenticated;

alter table public.shops enable row level security;
alter table public.profiles enable row level security;

drop policy if exists "shop members can read shop" on public.shops;
create policy "shop members can read shop" on public.shops for select using (id=public.my_shop_id());

drop policy if exists "shop members can update shop" on public.shops;
create policy "shop members can update shop" on public.shops for update using (id=public.my_shop_id()) with check (id=public.my_shop_id());

drop policy if exists "users can read own profile" on public.profiles;
create policy "users can read own profile" on public.profiles for select using (id=auth.uid());

drop policy if exists "shop members can read profiles" on public.profiles;
create policy "shop members can read profiles" on public.profiles for select using (shop_id=public.my_shop_id());

create or replace function public.handle_new_owner()
returns trigger language plpgsql security definer set search_path=public
as $$
declare s uuid;
begin
  if coalesce(new.raw_user_meta_data->>'role','owner') <> 'owner' then return new; end if;
  insert into public.shops(owner_id, name) values(new.id, coalesce(new.raw_user_meta_data->>'shop_name','Maithri Medical & General Stores')) returning id into s;
  insert into public.profiles(id,shop_id,username,full_name,role)
  values(new.id,s,lower(trim(new.raw_user_meta_data->>'username')),coalesce(new.raw_user_meta_data->>'full_name','Shop Owner'),'owner');
  return new;
end $$;

drop trigger if exists on_auth_user_created_maithri on auth.users;
create trigger on_auth_user_created_maithri after insert on auth.users for each row execute function public.handle_new_owner();

-- Keep updated_at current.
create or replace function public.touch_shop_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
drop trigger if exists shops_touch_updated_at on public.shops;
create trigger shops_touch_updated_at before update on public.shops for each row execute function public.touch_shop_updated_at();
